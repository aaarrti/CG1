import * as utils from "./lib/utils";

export const SIDE_LEN = 0.5;
export const RADIUS = 0.66;
export const ROTATION_ANGLE_RAD = utils.degToRad(10)